import java.util.Scanner;

public class OperationsHW {
	public static void main(String[] args) {
		//Let's declare two variable
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Enter the first number:");
		double num1 = keyboard.nextDouble();
		System.out.println("Enter the second number:");
		double num2 = keyboard.nextDouble();
		
		//Addition
		double addition = num1 + num2;
		System.out.println("Addition result is " + addition);
		//Subtraction
		double subtraction = num1 - num2;
		System.out.println("Subtraction result is " + subtraction);
		//Multiplication
		double multiplication = num1*num2;
		System.out.println("Multiplication result is "+ multiplication);
		//Division
		double division = num1/num2;
		System.out.println("Division result is "+ division);
		
		 
		
		 
		
	}

}
