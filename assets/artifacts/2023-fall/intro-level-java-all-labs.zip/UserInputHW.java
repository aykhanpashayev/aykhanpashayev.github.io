import java.util.Scanner;

public class UserInputHW {
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in); //Created a scanner object
		System.out.println("What is your name?");
		String name = keyboard.next(); //read the user input assign it to name
		System.out.println("What is your age?");
		int age = keyboard.nextInt();
		System.out.println("What is your annual income?");
		double income = keyboard.nextDouble();
		double mounthlyIncome = income/12;
		System.out.println("Hi " + name + " you are " + age + " years old and your mounthly income is $" + mounthlyIncome);
		
		
	}

}
