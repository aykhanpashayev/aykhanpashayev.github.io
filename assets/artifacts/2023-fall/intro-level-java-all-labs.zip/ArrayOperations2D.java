import java.util.Random;
import java.util.Scanner;

public class ArrayOperations2D {
    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Enter the size of array:");
        int size = keyboard.nextInt();
        System.out.println("The 2D array:");
        int[][] matrix = ArrayGenerator(size);

        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                System.out.print(matrix[i][j] + " ");
            }
            System.out.println(); 
        }
        System.out.println("The average for second column: "+avgColumn(matrix, 1));
        
        System.out.println("The maximum value for our array: "+findMax(matrix));
    }

    public static int[][] ArrayGenerator(int size) {
        Random rnd = new Random();
        int[][] matrix = new int[size][size];
        for (int i = 0; i < size; i++) {
            for (int j = 0; j < size; j++) {
                matrix[i][j] = rnd.nextInt(10) + 1;
            }
        }
        return matrix;
    }
    public static double avgColumn(int[][] matrix, int columnIndex) {
        int sum = 0;
        for (int row = 0; row < matrix.length; row++) {
            sum += matrix[row][columnIndex];
        }
        return (double) sum / matrix.length;
    }
    public static int findMax(int[][] matrix) {
        int max = matrix[0][0];

        for (int i = 0; i < matrix.length; i++) {
            for (int j = 0; j < matrix[i].length; j++) {
                if (matrix[i][j] > max) {
                    max = matrix[i][j];
                }
            }
        }
        return max;
    }
}
 
