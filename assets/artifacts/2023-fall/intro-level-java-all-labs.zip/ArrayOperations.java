import java.util.Random;
import java.util.Scanner;

public class ArrayOperations {
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		
		System.out.println("Enter the size of arrays:");
		int size = keyboard.nextInt();
		
		int[]array1=ArrayGenerator(size);
		int[]array2=ArrayGenerator(size);
		
		System.out.println("First array:");
		for(int numbers: array1) {
			System.out.print(numbers+" ");
		}
		System.out.println("\nSecond array:");
		for(int numbers: array2) {
			System.out.print(numbers+" ");
		}
		ArrayStats(array1);
		ArrayStats(array2);
		
		medianFinder(array1);
		medianFinder(array2);
		
		System.out.println("Third array (Doubled version of second array):");
		int[]array3=doubleArray(array2);
		for(int numbers: array3) {
			System.out.print(numbers+" ");
		}
		System.out.println("\nDifferences in indexs between first and second array");
		findDifference(array1, array2);
	}
	public static int[] ArrayGenerator(int size) {
		Random rnd = new Random();
		int[] arr = new int[size];
		for(int i=0;i<arr.length;i++) {
			arr[i]=rnd.nextInt(10)+1;
		}
		return arr;
	}
	public static int[] ArrayStats(int[] arr) {
	    int lowest = arr[0]; 
	    int greatest = arr[0]; 

	    for (int i = 1; i < arr.length; i++) {
	        if (arr[i] > greatest) {
	            greatest = arr[i];
	        } else if (arr[i] < lowest) {
	            lowest = arr[i];
	        }
	    }

	    System.out.println("\nGreatest is: " + greatest + "\nLowest is: " + lowest);
	    return arr;
	}
	public static double medianFinder(int[] arr) { 
		int mid = arr.length/2;
		if(arr.length%2==0) { 
			int median = (arr[mid-1]+arr[mid])/2;
			System.out.println("The median value is: "+(double)(arr[mid-1]+arr[mid])/2);
			return median;
		}
		else {
			int median = arr[mid];
			System.out.println("The median value is: "+arr[mid]);
			return median;
		}
	}
	public static int[] doubleArray(int[] arr) {
        int[] doubledArray = new int[arr.length];
        for (int i = 0; i < arr.length; i++) { 
            doubledArray[i] = arr[i] * 2;
        }
        return doubledArray;
    }
	public static void findDifference(int[] arr1, int[] arr2) {
        for (int i = 0; i < arr1.length; i++) {
            if (arr1[i] != arr2[i]) { 
                System.out.println("\nIndex: " + i);
            }
        }
    }
}
