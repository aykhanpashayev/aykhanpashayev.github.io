import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class task1 {
    public static void main(String[] args) throws FileNotFoundException {
        PrintWriter outputFile = new PrintWriter("football_scores.txt");
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Please enter the number of football games you want to record: ");
        int userInput = keyboard.nextInt();
        keyboard.nextLine();

        for (int i = 1; i <= userInput; i++) {
            System.out.println("Game " + i);
            System.out.println("Enter name of the first team:");
            String firstTeamName = keyboard.nextLine();

            System.out.println("Enter the score of " + firstTeamName);
            String firstTeamScore = keyboard.nextLine();
           

            System.out.println("Enter name of the second team:");
            String secondTeamName = keyboard.nextLine();

            System.out.println("Enter the score of " + secondTeamName);
            String secondTeamScore = keyboard.nextLine();
            

            outputFile.println(firstTeamName);
            outputFile.println(firstTeamScore);
            outputFile.println(secondTeamName);
            outputFile.println(secondTeamScore);
        }
        outputFile.close();
    }
}
