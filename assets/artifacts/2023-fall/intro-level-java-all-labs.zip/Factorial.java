import java.util.Scanner;

public class Factorial {
	public static void main(String[] args) {
		
		System.out.print("Enter positive number:"); //Let's ask our question to user
		Scanner keyboard =  new Scanner(System.in); //For user input let's add our scanner object
		int input = keyboard.nextInt();
		
		if(input<=0) {
			System.out.print("Invalid input: Enter positive number"); //If user enter negative number we will see this error message
		}
		else {
			//Let's declare variable for factorial
			int result =1;
			
			//Now let's use for loop to calculate factorial
			for(int i=1; i<=input; i++) {
				result = result*i; 
			}
			System.out.print("The factorial of "+ input+ " is " + result); //Let's display the result.
		}
		
	}

}
