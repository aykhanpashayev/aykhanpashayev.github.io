import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class task2 {
    public static void main(String[] args) throws FileNotFoundException {
        File myFile = new File("football_scores.txt");
        Scanner reader = new Scanner(myFile);
        
        String firstTeamName = reader.nextLine();
        int firstTeamScore = Integer.parseInt(reader.nextLine());

        String secondTeamName = reader.nextLine();
        int secondTeamScore = Integer.parseInt(reader.nextLine());
        
        String winner;

        if (firstTeamScore > secondTeamScore) {
            winner = firstTeamName;
        } else if (secondTeamScore > firstTeamScore) {
            winner = secondTeamName;
        } else {
            winner = " not only one team. There's equality";
        }
        
        System.out.println("Winner is " + winner);
    }
}

