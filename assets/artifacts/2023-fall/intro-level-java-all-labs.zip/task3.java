import java.util.Scanner;

public class task3 {
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in);
		System.out.println("Enter the seonds:");
		int seconds =  keyboard.nextInt();
		int minutes = seconds/60;
		int remainingSeconds = seconds%60;
		System.out.println(seconds+" seconds means " + minutes +" minutes and "+ remainingSeconds +" seconds.");
	}

}
