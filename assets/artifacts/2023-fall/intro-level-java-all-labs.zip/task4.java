import java.util.Scanner;

public class task4 {
    public static boolean isPalindrome(String s) {
        int x = 0;
        int y = s.length() - 1;
        while (x < y) {
        	x++;
            y--;
            if (s.charAt(x) == s.charAt(y)) {
                return true;
            }
        }
        return false;
    }

    public static void main(String[] args) {
        Scanner keyboard = new Scanner(System.in);
        System.out.println("Enter the word: ");
        String word = keyboard.nextLine();

        if (isPalindrome(word)) {
            System.out.println("It is a palindrome word!");
        } else {
            System.out.println("It is not a palindrome word!");
        }
    }
}

		