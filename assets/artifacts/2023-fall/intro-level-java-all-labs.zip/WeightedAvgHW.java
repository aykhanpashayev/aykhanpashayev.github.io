import java.util.Scanner;

public class WeightedAvgHW {
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in); //Created scanner object
		
		System.out.println("Please enter your 1st quiz grade?"); //I asked from the user to input quiz grades
		double quiz1 = keyboard.nextDouble();
		System.out.println("Please enter your 2nd quiz grade?");
		double quiz2 = keyboard.nextDouble();
		System.out.println("Please enter your 3rd quiz grade?");
		double quiz3 = keyboard.nextDouble();
		System.out.println("Please enter your 4th quiz grade?");
		double quiz4 = keyboard.nextDouble();
		System.out.println("Please enter your 5th quiz grade?");
		double quiz5 = keyboard.nextDouble();
		
		System.out.println("Please enter your 1st homework grade?");// I asked from user to homework grades
		double homework1 = keyboard.nextDouble();
		System.out.println("Please enter your 2nd homework grade?");
		double homework2 = keyboard.nextDouble();
		System.out.println("Please enter your 3rd homework grade?");
		double homework3 = keyboard.nextDouble();
		System.out.println("Please enter your 4th homework grade?");
		double homework4 = keyboard.nextDouble();
		System.out.println("Please enter your 5th homework grade?");
		double homework5 = keyboard.nextDouble();
		
		System.out.println("Please enter your lab grade?");
		double labGrade = keyboard.nextDouble();
		
		System.out.println("Please enter your final test grade?");
		double finalGrade = keyboard.nextDouble();
		
		System.out.println("Please enter your extra credits grade?");
		double extraGrade = keyboard.nextDouble();
		/*
		 *  After asking all grade types from the user let's calculate to weighted average. 
		 *  For calculating quiz grades I added all grades divide by 5 so I got the average grade for quiz and multiplied by 0.15 cause the sum of quizzes is 15%
		 *  I did the same thing for homework grade there were just lab, final and extra credit grades and I multiplied them by their %.
		 */
		
		double weightedAverage = (quiz1+quiz2+quiz3+quiz4+quiz5)/5*0.15 +
				(homework1+homework2+homework3+homework4+homework5)/5 * 0.5 + 
				labGrade*0.15 + finalGrade*0.2+ extraGrade*0.05;
		
		System.out.println("The weighted average is " + weightedAverage);
	}

}
