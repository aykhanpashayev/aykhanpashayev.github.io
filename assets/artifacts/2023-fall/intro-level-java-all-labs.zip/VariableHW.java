import java.util.Scanner;

public class VariableHW {
	public static void main(String[] args) {
		Scanner keyboard = new Scanner(System.in); //Created a scanner object
		
		System.out.println("What is current temperature in Celsius?"); //First let's ask current temp from the user
		double currentTemperature = keyboard.nextDouble(); 
		
		System.out.println("How much the temperature has changed?"); //Then ask how much the temp has changed so, we can add that to the previous temp. 
		double changedTemperature = keyboard.nextDouble();
		
		double updateTemperature = currentTemperature + changedTemperature; //I am showing the change in temp in Celsius
		System.out.print("Temperature in Celsius has changed from "+currentTemperature);
		System.out.println(" to " + updateTemperature);
		
		double temperatureFahrenheit = updateTemperature *9/5 +32; //It's the formula for our conventor
		System.out.println("Current temperature in Celsius is " + updateTemperature);
		System.out.println("Current temperature in Fahrenheit is " + temperatureFahrenheit);
		
		
		
		
		
	}

}
