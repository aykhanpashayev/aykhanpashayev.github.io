import java.util.Scanner;

public class SumOfEvenNumbers {
	public static void main(String[] args) {
		
		System.out.print("Enter a positive number:"); //Let's ask our question to user
		Scanner keyboard = new Scanner(System.in); //For user answer we need scanner object
		int input = keyboard.nextInt(); //Let's declare variable for user input
		
		if(input<=0) { //If user input negative number or 0 we will see this error message
			System.out.print("Invalid input:Enter positive number");
		}
		else {
			int result = 0;
			int i = 2; //Our first even number is 2.
			
			while(i<=input) { //Let's use while loop
				
				result = result+i;
				i=i+2; //For next even number we have to add 2.
				
			}
			System.out.print("The sum of even numbers from 1 to " + input + " is "+ result); //Let's display the result
		}
		
	}

}
