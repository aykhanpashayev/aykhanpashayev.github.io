
public class DivisibleNumbers {
	public static void main (String[] args) {
		//Let's use our for loop
		for(int i=1;i<=100;i++) {
			//Let's use if, else if and if statements for our different conditions
			if(i==50) { //When our numbers reach 50 it will be terminated
				break;
			}
			else if(i%3==0 && i%5==0) {//If our number divisible by 5 and 3 in console we will see FizzBuzz
				System.out.println("FizzBuzz");
			}
			else if(i%5==0) {//If number divisible by just 5 we will see Buzz in console
				System.out.println("Buzz");
			}
			else if(i%3==0) {//If number divisible by 3 we will see Fizz in console
				System.out.println("Fizz");
			}
			else if(i%7==0) {//When our number divisible by 7 we will skip this number
				continue;
			}
			else {
				System.out.println(i);
			}
		}
	}

}
