import java.util.Random;
import java.util.Scanner;

public class GuessTheNumber {
	public static void main(String[] args) {
		Random random = new Random(); //Let's start creating with random number
		/*/
		 * We need create random number between 1-100 so, random.nextInt(100) gives us number between 0-99.
		 * 0 is inclusive 100 is exclusive so we can just add one to result for solve that.
		 */
		int randomNumber = random.nextInt(100)+1; 
		System.out.println("Welcome to game of Guess The Number");
		
		for(int attempts=1;attempts<=10;attempts++) {//Let's use for loop for user's attempts
			//Let's add our scanner object for user input
			Scanner keyboard = new Scanner(System.in);
			System.out.println("Attempt "+ attempts + " Enter the number:");
			int userInput = keyboard.nextInt();
			
			if(userInput==randomNumber) { //If user won the game we will see that message and our loop will be terminated
				System.out.println("Congrats you won the game!");
				break;
			}
			else if(userInput>randomNumber) { //We use else if for react user inputs
				System.out.println("Too high!");
			}
			else if(userInput<randomNumber) {
				System.out.println("Too low!");
			}
			if(attempts==10 && userInput!=randomNumber) { //In the last if user uses all attempt and still can't find the number we will see this message.
				System.out.println("Game over! You used your all attempts!");
			}
			
		}
		
		
		
		
	}

}
