
public class Canary extends Bird{
	
	//Field
	
	protected String color;
	
	//Constructor
	
	public Canary(String s, int a, String h,boolean c, String col) {
		super(s,a,h,c);
		color = col ;
	}
	
	//Setter
	
	public void setColor(String col) {
		color = col;
	}
	
	//Getter
	
	public String getColor() {
		return color;
	}
	
	//Overridden displayInfo()
	
	public void displayInfo() {
		System.out.println("Species: " + species + "\nAge: " + age + "\nHabitat: " + habitat + "\nCan fly? " + canFly + "\nColor: " + color);
	}

}
