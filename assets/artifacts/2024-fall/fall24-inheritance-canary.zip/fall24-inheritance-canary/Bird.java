
public class Bird extends Animal{
	
	//Field
	
	protected boolean canFly;
	
	//Constructor
	
	public Bird(String s, int a, String h, boolean c) {
		super(s,a,h);
		canFly = c;
	}
	
	//Setter
	
	public void setCanFly(boolean c) {
		canFly = c;
	}
	
	//Getter
	
	public boolean getCanFly() {
		return canFly;
	}
	
	//Overridden displayInfo() method
	
	public void displayInfo() {
		System.out.println("Species: " + species + "\nAge: " + age + "\nHabitat: " + habitat + "\nCan fly? " + canFly + "\n");
	}
	

}
