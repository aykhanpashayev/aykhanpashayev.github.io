
public class Animal {
	
	//Fields
	
	protected String species;
	protected int age;
	protected String habitat;
	
	//Constructor
	
	public Animal(String s, int a, String h) {
		species = s;
		age = a;
		habitat = h;
	}
	
	//Setters
	
	public void setSpecies(String s) {
		species =s;
	}
	public void setAge(int a) {
		age = a;
	}
	public void setHabitat(String h) {
		habitat = h;
	}
	
	//Getters
	
	public String getSpecies() {
		return species;
	}
	public int getAge() {
		return age;
	}
	public String getHabitat() {
		return habitat;
	}
	
	//Display info method
	
	public void displayInfo() {
		System.out.println("Species: " + species + "\nAge: " + age + "\nHabitat: " + habitat + "\n");
	}

}
