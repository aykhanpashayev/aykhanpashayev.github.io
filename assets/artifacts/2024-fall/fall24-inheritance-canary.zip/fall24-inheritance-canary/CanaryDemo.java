
public class CanaryDemo {

	public static void main(String[] args) {
		Canary c1 = new Canary("Bird",1,"Rainforest", true, "yellow");
		
		c1.displayInfo();
	}

}
