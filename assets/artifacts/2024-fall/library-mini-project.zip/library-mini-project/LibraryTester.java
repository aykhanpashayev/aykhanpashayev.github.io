
public class LibraryTester {
	
	public static void main(String[] args) {
		Book b1 = new Book("Arhur's Journal","Arhur Morgan", 1899,"978-1-56619-909-4",true,10000);
		Book b2 = new Book("John's Journal", "John Marsthon", 1914,"978-1-56619-909-5",true,5000);
		Book b3 = new Book("Red Dead Redemption 2","Rockstar Games", 2014, "978-1-56619-909-6", true,60);
		
		System.out.println("Book number 1:");
		System.out.println(b1.displayInfo());
		System.out.println("Book number 2:");
		System.out.println(b2.displayInfo());
		System.out.println("Book number 3:");
		System.out.println(b3.displayInfo());
		
		b1.borrowBook();
		b2.borrowBook();
		
		System.out.println("Total available books: " + b1.totalAvailableBooks());
		
		b2.returnBook();
		
		System.out.println("Total available books: " + b1.totalAvailableBooks());
		
		b2.calculateLateFee(5);
	}

}
