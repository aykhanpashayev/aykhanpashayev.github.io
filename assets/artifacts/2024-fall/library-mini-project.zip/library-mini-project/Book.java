public class Book {
	
	//Fields
	
	private String title;
	private String author;
	private int publicationYear;
	private String ISBN;
	private boolean available;
	private double price;
	private static int totalAvailableBooks = 0;
	
	//Constructor
	
	public Book(String t, String a, int publication, String isbn, boolean availability, double p) {
		title = t;
		author = a;
		publicationYear = publication;
		ISBN = isbn;
		available = availability;
		price = p;
		totalAvailableBooks++;
	}
	
	//Setters;
	
	public void setTitle(String t) {
		title = t;
	}
	public void setAuthor(String a) {
		author = a;
	}
	public void setPublicationYear(int publication) {
		publicationYear = publication;
	}
	public void setISBN(String isbn) {
		ISBN = isbn;
	}
	public void setAvailability(boolean availability) {
		available = availability;
	}
	public void setPrice(double p) {
		price = p;
	}
	
	
	//Getters
	
	public String getTitle() {
		return title;
	}
	public String getAuthor() {
		return author;
	}
	public int getPublicationYear() {
		return publicationYear;
	}
	public String getISBN() {
		return ISBN;
	}
	public boolean getAvailability() {
        return available;
	}
	public double getPrice() {
		return price;
	}
	public int totalAvailableBooks() {
		return totalAvailableBooks;
	}
	public String displayInfo() {
		return "Title: " + title + "\nAuthor: " + author + "\nPublication Year: " + publicationYear + "\nISBN: " + ISBN + "\nAvaibility: " + available + "\nPrice: $" + price;
	}
	public void borrowBook() {
		if(available == false) {
			System.out.println("Book already booked");
		}
		else {
			totalAvailableBooks--;
			System.out.println("You succesfully borrowed the book");
			available = false;
		}
	}
	public void returnBook() {
		if(available == true) {
			System.out.println("The book is already in library");
		}
		else {
			System.out.println("You succesfully returned the book");
			totalAvailableBooks++;
			available = true;
		}
	}
	public void calculateLateFee(int daysOverdue) {
		System.out.println("The late returning fee is: " + daysOverdue*0.5 +"$");
	}
	
}