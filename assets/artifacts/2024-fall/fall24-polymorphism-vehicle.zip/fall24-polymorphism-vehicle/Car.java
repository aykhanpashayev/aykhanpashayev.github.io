
public class Car extends Vehicle{
	
	public Car(String model) {
		super(model);
	}

	public void accelerate() {
		System.out.println(model + " is accelerating");
	}
	
	public void startEngine() {
		System.out.println(model + " engine's started");
	}
	public void stopEngine() {
		System.out.println(model + " engine's stopped");
	}
	
	public void fly() {
		System.out.println(model + " this vehicle can not fly!");
	}

}
