
public class Airplane extends Vehicle implements Flyable {

	public Airplane(String model) {
		super(model);
	}

	public void accelerate() {
		System.out.println(model + " takeoff speed");
	}
	
	public void startEngine() {
		System.out.println(model + " engine's started");
	}
	public void stopEngine() {
		System.out.println(model + " engine's stopped");
	}
	
	public void fly() {
		System.out.println(model + " is flying");
	}
	
}
