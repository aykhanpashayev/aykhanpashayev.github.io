
public abstract class Vehicle {
	
	protected String model;
	
	public Vehicle(String model) {
		this.model = model;
	}
	
	public abstract void accelerate();
	public abstract void startEngine();
	public abstract void stopEngine();

	public abstract void fly();
}
