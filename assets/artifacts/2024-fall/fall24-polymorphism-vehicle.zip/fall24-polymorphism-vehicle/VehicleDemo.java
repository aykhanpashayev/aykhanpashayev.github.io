
public class VehicleDemo {
	public static void main(String[] args) {
		Vehicle v1 = new Car("Toyota Camry");
		Vehicle v2 = new Car("Mercedes-Benz E350");
		
		Vehicle v3 = new Airplane("Boeng 787");
		Vehicle v4 = new Airplane("Boeng 777");
		
		Vehicle [] arrayForVehicle = {v1,v2,v3,v4};
		
		for(Vehicle x: arrayForVehicle) {
			x.accelerate();
		}
		
		Vehicle [] arrayFly = {v3,v4};
		
		for(Vehicle i: arrayFly) {
			i.fly();
		}
		
		
		
	}
}
